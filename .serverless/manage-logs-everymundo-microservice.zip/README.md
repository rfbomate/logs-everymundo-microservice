# logs-everymundo-microservice
Test for hiring process Rafael Felipe Bomate Gavio
