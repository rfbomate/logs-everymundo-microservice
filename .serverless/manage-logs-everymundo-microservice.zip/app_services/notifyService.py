from flask import jsonify
import os
import boto3
from datetime import datetime


def notifyService(request):
    actualDate = datetime.today().strftime('%Y-%m-%d')
    return jsonify({'message': 'Data saved ok', 'date': actualDate})
