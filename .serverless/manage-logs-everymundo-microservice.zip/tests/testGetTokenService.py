from email import header
import requests
import json

BASE_URL = 'https://js33rzfdnl.execute-api.us-east-1.amazonaws.com/dev/'


# verify error input param
def testVerifyIfSendSomeParam():
    header = {'content-type': 'application/json'}
    response = requests.post(BASE_URL+'filterLogs',
                             headers=header, data=json.dumps({}))
    responseJson = response.json()

    assert (response.status_code ==
            400 and responseJson['message'] == 'At least a param must send to filter logs')
